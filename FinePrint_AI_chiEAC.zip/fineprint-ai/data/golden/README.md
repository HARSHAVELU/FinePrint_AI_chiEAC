# Golden set status

30 synthetic documents; 204 single-pass expected facts. No real personal data. These are smoke-test fixtures, not the completed golden set. `python scripts/seed.py` reproduces them. Do not use smoke scores in resume claims.
