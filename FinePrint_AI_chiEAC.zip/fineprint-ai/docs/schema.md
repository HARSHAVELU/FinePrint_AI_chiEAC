# FinePrint input schema

CSV and XLSX use a header row. JSON uses an array of objects. Each row is one original section or paragraph. Limits: 5 MB and 400 rows; one document per upload.

| Field | Type | Rule |
|---|---|---|
| doc_id | string | Same on every row. Generated from the filename in fallback mode. |
| section_id | string | Unique within the file; generated r1, r2, etc. if absent. |
| text | string | Required, nonempty original passage; maximum 50,000 characters per row. |
| heading | string | Optional section name. |
| page | positive integer | Optional source page. |
| source_file | string | Optional original filename, never a path to open. |

Single-column fallback maps the column to text. `content`, `paragraph`, `clause`, or `body` also maps to text and produces an assumption notice. JSON strings are supported as paragraph rows. Empty files, mixed doc_ids, duplicate section_ids, invalid page values, and oversized files receive friendly errors. Backend identifiers must be strings. CSV and JSON should use UTF-8.

Examples and downloads are in `public/templates/`. Run `python scripts/seed.py` to reproduce them. The browser XLSX parser uses a row-limited read; the backend also guards expanded ZIP size. CSV formula-like strings are treated as text and never executed; no user-content spreadsheet export is provided.
