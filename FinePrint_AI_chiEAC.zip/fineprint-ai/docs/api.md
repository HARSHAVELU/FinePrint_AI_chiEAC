# API guide

Start the server using the README. Open `/docs` for interactive documentation and `/openapi.json` for the runtime-generated contract. No API key belongs in frontend code. No content should appear in access logs.

| Method | Path | Input | Result |
|---|---|---|---|
| GET | /health | none | mode and backend status |
| POST | /upload | multipart file; optional family_hint | session_id, family, redacted rows, assumptions, redacted count |
| POST | /search | session_id, question | up to five rows and retrieval scores |
| POST | /analyze | session_id | typed verified items, section rewrites, gap questions |
| POST | /ask | session_id, question | answer, abstained flag, citations, nearest passages |
| DELETE | /session/{session_id} | opaque session token | deletion confirmation |

```sh
curl -F file=@public/templates/fineprint-template.csv http://localhost:8000/upload
curl -H 'Content-Type: application/json' -d '{"session_id":"COPY_UPLOAD_TOKEN","question":"When is rent due?"}' http://localhost:8000/ask
```

The API uses 422 for invalid documents, 404 for expired sessions, 413 for oversized requests, 429 for rate limits, 503 for session capacity, and 504 for analysis timeout. Unexpected failures return a generic message; validation responses omit raw input values. Do not log request bodies, upload contents, session tokens, user questions, or provider responses. Rate limiting is per connection IP, so configure a trusted edge proxy before a shared deployment. CORS is an exact allowlist supplied through `FINEPRINT_ORIGINS`.

Retrieval scores are lexical coverage in demo mode and cosine similarity in Chroma mode; thresholds must be calibrated separately. Low retrieval scores or no verified answer spans cause abstention. Nearest passages are labeled separately and may not answer the question.
